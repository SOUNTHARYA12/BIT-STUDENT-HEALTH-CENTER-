import React, { useEffect, useState } from 'react';
import { apiFetch } from '../../lib/api';
import { Appointment } from '../../types';
import { StatusBadge } from '../common/StatusBadge';
import { useNavigate } from 'react-router-dom';
import {
  Radio,
  Play,
  CheckCircle,
  XCircle,
  Stethoscope,
  RefreshCw,
  Clock,
  User,
  AlertCircle,
} from 'lucide-react';

export const DoctorQueue: React.FC = () => {
  const navigate = useNavigate();
  const [appointments, setAppointments] = useState<Appointment[]>([]);
  const [loading, setLoading] = useState(true);
  const [statusMsg, setStatusMsg] = useState<string | null>(null);

  const todayStr = new Date().toISOString().split('T')[0];

  useEffect(() => {
    loadQueue();
    const interval = setInterval(loadQueue, 10000);
    return () => clearInterval(interval);
  }, []);

  const loadQueue = async () => {
    try {
      const data = await apiFetch<Appointment[]>(`/api/appointments?date=${todayStr}`);
      setAppointments(data);
    } catch (err) {
      console.error('Queue load error:', err);
    } finally {
      setLoading(false);
    }
  };

  const handleUpdateStatus = async (id: string, status: string) => {
    setStatusMsg(null);
    try {
      await apiFetch(`/api/appointments/${id}/status`, {
        method: 'PATCH',
        body: JSON.stringify({ status }),
      });
      setStatusMsg(`Updated token status to ${status}.`);
      await loadQueue();

      if (status === 'in_consultation') {
        navigate(`/doctor/workspace?apptId=${id}`);
      }
    } catch (err: any) {
      setStatusMsg(err.message || 'Failed to update token.');
    }
  };

  const waitingList = appointments.filter(a => ['checked_in', 'booked'].includes(a.status));
  const activeInConsult = appointments.find(a => a.status === 'in_consultation');
  const completedList = appointments.filter(a => a.status === 'completed');

  return (
    <div className="space-y-6">
      
      {/* Title */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="w-2.5 h-2.5 rounded-full bg-teal-500 animate-pulse" />
            <h1 className="text-xl font-bold text-[#0f2942]">OPD Patient Queue & Token Calling</h1>
          </div>
          <p className="text-xs text-slate-500 mt-0.5">
            Manage your daily patient queue, call waiting tokens, and track consultation progress.
          </p>
        </div>

        <button
          onClick={loadQueue}
          className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-white border border-slate-300 text-xs font-medium text-slate-700 rounded-lg hover:bg-slate-50 transition shadow-2xs self-start sm:self-auto cursor-pointer"
        >
          <RefreshCw className="w-3.5 h-3.5 text-teal-600" />
          <span>Refresh Queue</span>
        </button>
      </div>

      {statusMsg && (
        <div className="p-3 bg-teal-50 border border-teal-200 text-teal-800 text-xs rounded-lg">
          {statusMsg}
        </div>
      )}

      {/* Currently in Consultation Spotlight Card */}
      <div className="bg-white rounded-xl border border-slate-200 p-6 shadow-2xs">
        <div className="text-[10px] font-bold text-amber-700 uppercase tracking-wider mb-2 flex items-center gap-1.5">
          <Radio className="w-3.5 h-3.5 text-amber-600 animate-pulse" />
          <span>Currently in OPD Consultation Room</span>
        </div>

        {activeInConsult ? (
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 p-4 bg-amber-50/60 rounded-xl border border-amber-200">
            <div className="flex items-center gap-4">
              <div className="w-14 h-14 rounded-xl bg-amber-100 border border-amber-300 text-amber-900 flex flex-col items-center justify-center font-mono shrink-0">
                <span className="text-[9px] uppercase font-bold text-amber-700">Token</span>
                <span className="text-xl font-black">#{activeInConsult.token_number}</span>
              </div>
              <div>
                <h2 className="text-base font-bold text-slate-900">{activeInConsult.student_name}</h2>
                <div className="text-xs text-slate-600 font-mono">
                  Roll: {activeInConsult.student_roll} • {activeInConsult.time_slot}
                </div>
                <div className="text-xs text-slate-500 mt-0.5 italic">
                  "{activeInConsult.reason_for_visit}"
                </div>
              </div>
            </div>

            <div className="flex items-center gap-2">
              <button
                onClick={() => navigate(`/doctor/workspace?apptId=${activeInConsult.id}`)}
                className="px-4 py-2 bg-[#0f2942] hover:bg-[#163654] text-white text-xs font-semibold rounded-lg transition flex items-center gap-1.5 shadow-xs"
              >
                <Stethoscope className="w-4 h-4 text-teal-300" />
                <span>Open Clinical Workspace</span>
              </button>
            </div>
          </div>
        ) : (
          <div className="p-6 text-center bg-slate-50 rounded-xl border border-dashed border-slate-200">
            <p className="text-xs font-medium text-slate-600">No patient is currently in your consultation room.</p>
            <p className="text-[11px] text-slate-400 mt-0.5">Click "Call Patient" on any waiting token below to invite them into the OPD.</p>
          </div>
        )}
      </div>

      {/* Waiting Tokens Table */}
      <div className="bg-white rounded-xl border border-slate-200 overflow-hidden shadow-2xs">
        <div className="px-5 py-4 bg-slate-50 border-b border-slate-200 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Clock className="w-4 h-4 text-teal-700" />
            <h2 className="text-xs font-bold text-[#0f2942] uppercase tracking-wider">
              Waiting Queue ({waitingList.length} Patients)
            </h2>
          </div>
          <span className="text-[11px] text-slate-500">Ordered by sequential token number</span>
        </div>

        {loading ? (
          <div className="p-8 text-center text-xs text-slate-400">Loading patient queue...</div>
        ) : waitingList.length === 0 ? (
          <div className="p-8 text-center text-xs text-slate-500">
            No patients currently waiting in line.
          </div>
        ) : (
          <div className="divide-y divide-slate-100">
            {waitingList.map((item) => (
              <div
                key={item.id}
                className="p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3 hover:bg-slate-50/80 transition"
              >
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-lg bg-teal-50 border border-teal-200 text-teal-800 flex flex-col items-center justify-center font-mono shrink-0">
                    <span className="text-[8px] uppercase font-bold text-teal-600">Token</span>
                    <span className="text-sm font-extrabold text-[#0f2942]">#{item.token_number}</span>
                  </div>
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="font-bold text-xs text-slate-900">{item.student_name}</span>
                      <span className="text-[10px] font-mono text-slate-500">({item.student_roll})</span>
                      <StatusBadge status={item.status} size="sm" />
                    </div>
                    <div className="text-xs text-slate-600 mt-0.5">
                      Dept: {item.student_department} ({item.student_year}) • Blood: <span className="font-semibold text-rose-700">{item.student_blood_group || 'O+'}</span>
                    </div>
                    <div className="text-[11px] text-slate-500 mt-0.5 italic">
                      Chief Complaint: "{item.reason_for_visit}"
                    </div>
                  </div>
                </div>

                <div className="flex items-center gap-2 self-end sm:self-center">
                  <div className="text-right text-xs mr-2 font-mono text-slate-500 hidden sm:block">
                    {item.time_slot}
                  </div>

                  <button
                    onClick={() => handleUpdateStatus(item.id, 'in_consultation')}
                    className="px-3 py-1.5 bg-teal-600 hover:bg-teal-700 text-white text-xs font-semibold rounded-lg transition flex items-center gap-1.5 shadow-2xs cursor-pointer"
                  >
                    <Play className="w-3.5 h-3.5 fill-current" />
                    <span>Call Patient</span>
                  </button>

                  <button
                    onClick={() => handleUpdateStatus(item.id, 'no_show')}
                    className="px-2.5 py-1.5 text-slate-500 hover:text-rose-600 hover:bg-rose-50 border border-slate-200 rounded-lg text-xs transition cursor-pointer"
                    title="Mark Absent / No Show"
                  >
                    <XCircle className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Completed Today Accordion */}
      {completedList.length > 0 && (
        <div className="bg-white rounded-xl border border-slate-200 p-5 shadow-2xs">
          <div className="text-xs font-bold text-slate-700 uppercase tracking-wider mb-3">
            Completed Consultations Today ({completedList.length})
          </div>
          <div className="divide-y divide-slate-100 text-xs">
            {completedList.map(c => (
              <div key={c.id} className="py-2.5 flex items-center justify-between">
                <div>
                  <span className="font-mono font-bold text-slate-800">Token #{c.token_number}</span>
                  <span className="text-slate-600 ml-2">{c.student_name}</span>
                  <span className="text-[11px] text-slate-400 font-mono ml-2">({c.appointment_number})</span>
                </div>
                <div className="flex items-center gap-2">
                  <span className="text-emerald-700 font-medium">Completed</span>
                  <button
                    onClick={() => navigate(`/doctor/workspace?apptId=${c.id}`)}
                    className="text-xs text-teal-700 hover:text-teal-900 underline ml-2"
                  >
                    View Record
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

    </div>
  );
};
