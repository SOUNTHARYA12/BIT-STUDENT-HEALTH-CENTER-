import React, { useState, useEffect } from 'react';
import { useSearchParams, useNavigate } from 'react-router-dom';
import { apiFetch } from '../../lib/api';
import { Appointment, Medicine, PrescriptionItem } from '../../types';
import { StatusBadge } from '../common/StatusBadge';
import { PrescriptionModal } from '../common/PrescriptionModal';
import {
  Stethoscope,
  Activity,
  HeartPulse,
  Pill,
  Save,
  Plus,
  Trash2,
  CheckCircle2,
  AlertCircle,
  FileText,
  Clock,
  User,
  AlertTriangle,
  History,
} from 'lucide-react';

export const DoctorWorkspace: React.FC = () => {
  const [searchParams] = useSearchParams();
  const apptIdParam = searchParams.get('apptId');
  const navigate = useNavigate();

  const [appointments, setAppointments] = useState<Appointment[]>([]);
  const [selectedApptId, setSelectedApptId] = useState<string>(apptIdParam || '');
  const [selectedAppt, setSelectedAppt] = useState<Appointment | null>(null);

  // Vitals
  const [bp, setBp] = useState('120/80 mmHg');
  const [pulse, setPulse] = useState('74');
  const [temp, setTemp] = useState('98.6');
  const [spo2, setSpo2] = useState('99');
  const [weight, setWeight] = useState('62.5');

  // Clinical Notes
  const [symptoms, setSymptoms] = useState('');
  const [clinicalNotes, setClinicalNotes] = useState('');
  const [diagnosis, setDiagnosis] = useState('');
  const [treatment, setTreatment] = useState('');
  const [doctorAdvice, setDoctorAdvice] = useState('Take medications after food. Maintain hydration. Review if symptoms worsen.');
  const [followUpDate, setFollowUpDate] = useState('');

  // Pharmacy Catalog for Prescription
  const [pharmacyMeds, setPharmacyMeds] = useState<Medicine[]>([]);
  const [rxItems, setRxItems] = useState<any[]>([]);

  // Item being added
  const [medSearch, setMedSearch] = useState('');
  const [selectedMedId, setSelectedMedId] = useState('');
  const [itemDosage, setItemDosage] = useState('1 Tablet');
  const [itemFrequency, setItemFrequency] = useState('1-0-1 (Twice daily after food)');
  const [itemDuration, setItemDuration] = useState('3 Days');
  const [itemRoute, setItemRoute] = useState('Oral');
  const [itemInstruction, setItemInstruction] = useState('Take with warm water after meals');
  const [itemQty, setItemQty] = useState(6);

  // Status & modal
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [statusMsg, setStatusMsg] = useState<{ type: 'success' | 'error'; text: string } | null>(null);
  const [issuedRx, setIssuedRx] = useState<any | null>(null);

  useEffect(() => {
    loadAppointmentsAndCatalog();
  }, []);

  useEffect(() => {
    if (selectedApptId && appointments.length > 0) {
      const match = appointments.find(a => a.id === selectedApptId);
      if (match) {
        setSelectedAppt(match);
        setSymptoms(match.reason_for_visit || '');
      }
    }
  }, [selectedApptId, appointments]);

  const loadAppointmentsAndCatalog = async () => {
    setLoading(true);
    try {
      const todayStr = new Date().toISOString().split('T')[0];
      const [apptsData, medsData] = await Promise.all([
        apiFetch<Appointment[]>(`/api/appointments?date=${todayStr}`),
        apiFetch<Medicine[]>('/api/pharmacy/medicines'),
      ]);

      const actionable = apptsData.filter(a => ['checked_in', 'in_consultation', 'booked'].includes(a.status));
      setAppointments(actionable);
      setPharmacyMeds(medsData);

      if (medsData.length > 0) {
        setSelectedMedId(medsData[0].id);
      }

      if (apptIdParam) {
        setSelectedApptId(apptIdParam);
      } else if (actionable.length > 0) {
        setSelectedApptId(actionable[0].id);
      }
    } catch (err) {
      console.error('Failed to load workspace data:', err);
    } finally {
      setLoading(false);
    }
  };

  const handleAddMedicineItem = () => {
    const med = pharmacyMeds.find(m => m.id === selectedMedId);
    if (!med) return;

    const newItem = {
      medicine_id: med.id,
      medicine_name: `${med.name} (${med.strength})`,
      dosage: itemDosage,
      frequency: itemFrequency,
      duration: itemDuration,
      route: itemRoute,
      instructions: itemInstruction,
      quantity_prescribed: itemQty,
      available_stock: med.total_stock,
    };

    setRxItems(prev => [...prev, newItem]);
  };

  const handleRemoveRxItem = (index: number) => {
    setRxItems(prev => prev.filter((_, idx) => idx !== index));
  };

  const handleSubmitConsultation = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedApptId) return;

    if (!diagnosis.trim()) {
      setStatusMsg({ type: 'error', text: 'Diagnosis summary is mandatory to complete a medical consultation.' });
      return;
    }

    setSaving(true);
    setStatusMsg(null);

    try {
      const payload = {
        vitals_bp: bp,
        vitals_pulse: pulse,
        vitals_temp: temp,
        vitals_spo2: spo2,
        vitals_weight: weight,
        symptoms,
        clinical_notes: clinicalNotes,
        diagnosis,
        treatment_recommendations: treatment,
        doctor_advice: doctorAdvice,
        follow_up_date: followUpDate || null,
        prescription_items: rxItems,
      };

      const res = await apiFetch(`/api/consultations/${selectedApptId}/save`, {
        method: 'POST',
        body: JSON.stringify(payload),
      });

      setStatusMsg({ type: 'success', text: 'Consultation successfully recorded and digital prescription issued.' });
      
      // Load the issued prescription for immediate printing / review
      const apptDetails = await apiFetch(`/api/consultations/${selectedApptId}`);
      if (apptDetails.prescription) {
        setIssuedRx(apptDetails.prescription);
      }

      await loadAppointmentsAndCatalog();
    } catch (err: any) {
      setStatusMsg({ type: 'error', text: err.message || 'Failed to record consultation.' });
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="space-y-6">
      
      {/* Workspace Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <Stethoscope className="w-5 h-5 text-teal-700" />
            <h1 className="text-xl font-bold text-[#0f2942]">OPD Clinical Workspace & Prescription Writer</h1>
          </div>
          <p className="text-xs text-slate-500 mt-0.5">
            Record patient vital signs, clinical examination, ICD diagnosis, and formulate digital prescriptions.
          </p>
        </div>

        {/* Patient Selection Dropdown */}
        <div className="flex items-center gap-2 self-start sm:self-auto">
          <span className="text-xs font-semibold text-slate-600">Select Patient:</span>
          <select
            value={selectedApptId}
            onChange={(e) => setSelectedApptId(e.target.value)}
            className="px-3 py-1.5 text-xs bg-white border border-slate-300 rounded-lg text-slate-800 font-medium"
          >
            {appointments.map((a) => (
              <option key={a.id} value={a.id}>
                Tk #{a.token_number} - {a.student_name} ({a.time_slot})
              </option>
            ))}
            {appointments.length === 0 && <option value="">No patients waiting</option>}
          </select>
        </div>
      </div>

      {statusMsg && (
        <div
          className={`p-3.5 rounded-lg text-xs flex items-center justify-between gap-2 ${
            statusMsg.type === 'success'
              ? 'bg-emerald-50 text-emerald-800 border border-emerald-200'
              : 'bg-rose-50 text-rose-800 border border-rose-200'
          }`}
        >
          <div className="flex items-center gap-2">
            {statusMsg.type === 'success' ? (
              <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
            ) : (
              <AlertCircle className="w-4 h-4 text-rose-600 shrink-0" />
            )}
            <span>{statusMsg.text}</span>
          </div>

          {issuedRx && (
            <button
              onClick={() => setIssuedRx(issuedRx)}
              className="text-xs font-bold text-teal-800 underline"
            >
              Print Prescription Document
            </button>
          )}
        </div>
      )}

      {selectedAppt ? (
        <form onSubmit={handleSubmitConsultation} className="space-y-6">
          
          {/* Patient Card Header */}
          <div className="bg-white rounded-xl border border-slate-200 p-5 shadow-2xs">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-100 pb-4">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 rounded-xl bg-teal-50 border border-teal-200 text-teal-800 flex flex-col items-center justify-center font-mono shrink-0">
                  <span className="text-[9px] uppercase font-bold text-teal-600">Token</span>
                  <span className="text-base font-black">#{selectedAppt.token_number}</span>
                </div>
                <div>
                  <span className="font-mono text-xs text-slate-400">{selectedAppt.appointment_number}</span>
                  <h2 className="text-base font-bold text-slate-900">{selectedAppt.student_name}</h2>
                  <div className="text-xs text-slate-600">
                    Roll: <strong className="font-mono">{selectedAppt.student_roll}</strong> • Dept: {selectedAppt.student_department} ({selectedAppt.student_year})
                  </div>
                </div>
              </div>

              <div className="flex items-center gap-3 text-xs">
                <div className="p-2.5 bg-rose-50 border border-rose-200 rounded-lg text-center">
                  <span className="text-[10px] text-rose-500 uppercase block font-semibold">Blood Group</span>
                  <span className="font-bold text-rose-700">{selectedAppt.student_blood_group || 'O+'}</span>
                </div>
                <div className="p-2.5 bg-slate-50 border border-slate-200 rounded-lg text-left">
                  <span className="text-[10px] text-slate-400 uppercase block font-semibold">Scheduled Mode</span>
                  <span className="font-bold text-slate-800 capitalize">{selectedAppt.consultation_type.replace('_', ' ')}</span>
                </div>
                <StatusBadge status={selectedAppt.status} />
              </div>
            </div>

            <div className="mt-3 text-xs text-slate-600">
              <span className="font-semibold text-slate-700">Reason for visit: </span>
              <span className="italic">"{selectedAppt.reason_for_visit}"</span>
            </div>
          </div>

          {/* Section 1: Vital Signs Entry */}
          <div className="bg-white rounded-xl border border-slate-200 p-5 shadow-2xs space-y-3">
            <h3 className="text-xs font-bold text-[#0f2942] uppercase tracking-wider flex items-center gap-2">
              <Activity className="w-4 h-4 text-teal-700" />
              <span>1. Recorded Vital Signs</span>
            </h3>

            <div className="grid grid-cols-2 sm:grid-cols-5 gap-3">
              <div>
                <label className="text-[11px] font-semibold text-slate-600 block mb-1">
                  Blood Pressure (mmHg)
                </label>
                <input
                  type="text"
                  value={bp}
                  onChange={(e) => setBp(e.target.value)}
                  placeholder="120/80"
                  className="w-full px-3 py-1.5 text-xs bg-slate-50 border border-slate-300 rounded-lg font-mono font-medium"
                />
              </div>

              <div>
                <label className="text-[11px] font-semibold text-slate-600 block mb-1">
                  Pulse Rate (bpm)
                </label>
                <input
                  type="number"
                  value={pulse}
                  onChange={(e) => setPulse(e.target.value)}
                  placeholder="72"
                  className="w-full px-3 py-1.5 text-xs bg-slate-50 border border-slate-300 rounded-lg font-mono font-medium"
                />
              </div>

              <div>
                <label className="text-[11px] font-semibold text-slate-600 block mb-1">
                  Body Temp (°F)
                </label>
                <input
                  type="number"
                  step="0.1"
                  value={temp}
                  onChange={(e) => setTemp(e.target.value)}
                  placeholder="98.6"
                  className="w-full px-3 py-1.5 text-xs bg-slate-50 border border-slate-300 rounded-lg font-mono font-medium"
                />
              </div>

              <div>
                <label className="text-[11px] font-semibold text-slate-600 block mb-1">
                  Oxygen SpO2 (%)
                </label>
                <input
                  type="number"
                  value={spo2}
                  onChange={(e) => setSpo2(e.target.value)}
                  placeholder="99"
                  className="w-full px-3 py-1.5 text-xs bg-slate-50 border border-slate-300 rounded-lg font-mono font-medium"
                />
              </div>

              <div>
                <label className="text-[11px] font-semibold text-slate-600 block mb-1">
                  Weight (kg)
                </label>
                <input
                  type="number"
                  step="0.1"
                  value={weight}
                  onChange={(e) => setWeight(e.target.value)}
                  placeholder="65"
                  className="w-full px-3 py-1.5 text-xs bg-slate-50 border border-slate-300 rounded-lg font-mono font-medium"
                />
              </div>
            </div>
          </div>

          {/* Section 2: Symptoms & Diagnosis */}
          <div className="bg-white rounded-xl border border-slate-200 p-5 shadow-2xs space-y-4">
            <h3 className="text-xs font-bold text-[#0f2942] uppercase tracking-wider flex items-center gap-2">
              <HeartPulse className="w-4 h-4 text-teal-700" />
              <span>2. Clinical Findings & Diagnosis</span>
            </h3>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="text-xs font-semibold text-slate-700 block mb-1">
                  Presenting Symptoms & History of Present Illness
                </label>
                <textarea
                  rows={3}
                  value={symptoms}
                  onChange={(e) => setSymptoms(e.target.value)}
                  placeholder="Reported symptoms, duration, onset..."
                  className="w-full px-3 py-2 text-xs bg-slate-50 border border-slate-300 rounded-lg"
                />
              </div>

              <div>
                <label className="text-xs font-semibold text-slate-700 block mb-1">
                  Physical Examination & Clinical Notes
                </label>
                <textarea
                  rows={3}
                  value={clinicalNotes}
                  onChange={(e) => setClinicalNotes(e.target.value)}
                  placeholder="General condition, chest sounds, throat congestion, tenderness..."
                  className="w-full px-3 py-2 text-xs bg-slate-50 border border-slate-300 rounded-lg"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2 border-t border-slate-100">
              <div>
                <label className="text-xs font-bold text-teal-900 block mb-1">
                  Clinical Diagnosis * (Required)
                </label>
                <input
                  type="text"
                  required
                  value={diagnosis}
                  onChange={(e) => setDiagnosis(e.target.value)}
                  placeholder="e.g. Acute Bronchitis, Tension Headache, Allergic Rhinitis"
                  className="w-full px-3 py-2 text-xs bg-teal-50/50 border border-teal-300 rounded-lg font-semibold text-teal-950"
                />
              </div>

              <div>
                <label className="text-xs font-semibold text-slate-700 block mb-1">
                  Follow-up Review Date (Optional)
                </label>
                <input
                  type="date"
                  value={followUpDate}
                  onChange={(e) => setFollowUpDate(e.target.value)}
                  className="w-full px-3 py-2 text-xs bg-slate-50 border border-slate-300 rounded-lg"
                />
              </div>
            </div>

            <div>
              <label className="text-xs font-semibold text-slate-700 block mb-1">
                Doctor's Advice & Patient Instructions
              </label>
              <input
                type="text"
                value={doctorAdvice}
                onChange={(e) => setDoctorAdvice(e.target.value)}
                className="w-full px-3 py-2 text-xs bg-slate-50 border border-slate-300 rounded-lg"
              />
            </div>
          </div>

          {/* Section 3: Digital Prescription Writer */}
          <div className="bg-white rounded-xl border border-slate-200 p-5 shadow-2xs space-y-4">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <h3 className="text-xs font-bold text-[#0f2942] uppercase tracking-wider flex items-center gap-2">
                <Pill className="w-4 h-4 text-teal-700" />
                <span>3. Formulate Digital Prescription (Rx)</span>
              </h3>
              <span className="text-[11px] text-slate-500">
                Connected directly to BIT Pharmacy stock database
              </span>
            </div>

            {/* Add Medicine Control Row */}
            <div className="p-4 bg-slate-50 rounded-xl border border-slate-200 space-y-3">
              <div className="text-[11px] font-semibold text-slate-700 uppercase tracking-wider">
                Add Medication from Pharmacy Catalog
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-4 gap-3 text-xs">
                <div className="sm:col-span-2">
                  <label className="text-[10px] text-slate-500 font-semibold uppercase block mb-1">
                    Select Medicine
                  </label>
                  <select
                    value={selectedMedId}
                    onChange={(e) => setSelectedMedId(e.target.value)}
                    className="w-full px-3 py-1.5 text-xs bg-white border border-slate-300 rounded-lg font-medium"
                  >
                    {pharmacyMeds.map(m => (
                      <option key={m.id} value={m.id}>
                        {m.name} - {m.strength} (Stock: {m.total_stock} {m.unit})
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="text-[10px] text-slate-500 font-semibold uppercase block mb-1">
                    Dosage
                  </label>
                  <input
                    type="text"
                    value={itemDosage}
                    onChange={(e) => setItemDosage(e.target.value)}
                    placeholder="1 Tablet"
                    className="w-full px-3 py-1.5 text-xs bg-white border border-slate-300 rounded-lg"
                  />
                </div>

                <div>
                  <label className="text-[10px] text-slate-500 font-semibold uppercase block mb-1">
                    Frequency
                  </label>
                  <input
                    type="text"
                    value={itemFrequency}
                    onChange={(e) => setItemFrequency(e.target.value)}
                    placeholder="1-0-1"
                    className="w-full px-3 py-1.5 text-xs bg-white border border-slate-300 rounded-lg"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-4 gap-3 text-xs">
                <div>
                  <label className="text-[10px] text-slate-500 font-semibold uppercase block mb-1">
                    Duration
                  </label>
                  <input
                    type="text"
                    value={itemDuration}
                    onChange={(e) => setItemDuration(e.target.value)}
                    placeholder="3 Days"
                    className="w-full px-3 py-1.5 text-xs bg-white border border-slate-300 rounded-lg"
                  />
                </div>

                <div>
                  <label className="text-[10px] text-slate-500 font-semibold uppercase block mb-1">
                    Food Instructions
                  </label>
                  <input
                    type="text"
                    value={itemInstruction}
                    onChange={(e) => setItemInstruction(e.target.value)}
                    placeholder="After Food"
                    className="w-full px-3 py-1.5 text-xs bg-white border border-slate-300 rounded-lg"
                  />
                </div>

                <div>
                  <label className="text-[10px] text-slate-500 font-semibold uppercase block mb-1">
                    Quantity Prescribed
                  </label>
                  <input
                    type="number"
                    min={1}
                    value={itemQty}
                    onChange={(e) => setItemQty(parseInt(e.target.value, 10) || 1)}
                    className="w-full px-3 py-1.5 text-xs bg-white border border-slate-300 rounded-lg font-mono font-bold"
                  />
                </div>

                <div className="flex items-end">
                  <button
                    type="button"
                    onClick={handleAddMedicineItem}
                    className="w-full py-1.5 px-3 bg-teal-600 hover:bg-teal-700 text-white text-xs font-semibold rounded-lg flex items-center justify-center gap-1.5 transition cursor-pointer"
                  >
                    <Plus className="w-4 h-4" />
                    <span>Add to Rx</span>
                  </button>
                </div>
              </div>
            </div>

            {/* Prescribed Items Table */}
            <div className="overflow-hidden border border-slate-200 rounded-lg">
              <table className="w-full text-left text-xs">
                <thead className="bg-slate-100 text-slate-600 font-semibold uppercase text-[10px]">
                  <tr>
                    <th className="px-3 py-2">#</th>
                    <th className="px-3 py-2">Medicine</th>
                    <th className="px-3 py-2">Dosage & Frequency</th>
                    <th className="px-3 py-2">Duration</th>
                    <th className="px-3 py-2">Instructions</th>
                    <th className="px-3 py-2 text-right">Qty</th>
                    <th className="px-3 py-2 text-center">Action</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-200">
                  {rxItems.map((item, idx) => (
                    <tr key={idx} className="hover:bg-slate-50">
                      <td className="px-3 py-2.5 text-slate-400 font-medium">{idx + 1}</td>
                      <td className="px-3 py-2.5 font-bold text-slate-900">{item.medicine_name}</td>
                      <td className="px-3 py-2.5 font-medium text-teal-800">{item.dosage} • {item.frequency}</td>
                      <td className="px-3 py-2.5 text-slate-700">{item.duration}</td>
                      <td className="px-3 py-2.5 text-slate-600 italic">{item.instructions}</td>
                      <td className="px-3 py-2.5 text-right font-mono font-bold text-slate-900">{item.quantity_prescribed}</td>
                      <td className="px-3 py-2.5 text-center">
                        <button
                          type="button"
                          onClick={() => handleRemoveRxItem(idx)}
                          className="p-1 text-rose-500 hover:text-rose-700 hover:bg-rose-50 rounded"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </td>
                    </tr>
                  ))}
                  {rxItems.length === 0 && (
                    <tr>
                      <td colSpan={7} className="px-4 py-4 text-center text-slate-400">
                        No medicines added to this prescription yet. Use the selector above to add.
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>

          </div>

          {/* Complete Consultation Button Bar */}
          <div className="p-4 bg-white rounded-xl border border-slate-200 shadow-2xs flex items-center justify-between">
            <div className="text-xs text-slate-500">
              Completing this consultation will update the patient's EMR record and transmit the prescription to the BIT Pharmacy counter.
            </div>

            <button
              type="submit"
              disabled={saving}
              className="px-6 py-2.5 bg-[#0f2942] hover:bg-[#163654] text-white text-xs font-semibold rounded-lg shadow-sm transition flex items-center gap-2 cursor-pointer disabled:opacity-50"
            >
              <Save className="w-4 h-4 text-teal-300" />
              <span>{saving ? 'Recording & Issuing...' : 'Complete Consultation & Issue Rx'}</span>
            </button>
          </div>

        </form>
      ) : (
        <div className="bg-white rounded-xl border border-slate-200 p-12 text-center text-xs text-slate-500">
          No active patient selected for consultation. Please select a patient from the queue.
        </div>
      )}

      {/* Prescription Modal for print review */}
      {issuedRx && (
        <PrescriptionModal
          prescription={issuedRx}
          onClose={() => setIssuedRx(null)}
        />
      )}

    </div>
  );
};
