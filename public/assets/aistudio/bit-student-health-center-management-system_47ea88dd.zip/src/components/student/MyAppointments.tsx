import React, { useEffect, useState } from 'react';
import { apiFetch } from '../../lib/api';
import { Appointment } from '../../types';
import { StatusBadge } from '../common/StatusBadge';
import { Link } from 'react-router-dom';
import {
  CalendarCheck,
  MapPin,
  Clock,
  Radio,
  XCircle,
  CheckCircle,
  AlertCircle,
  Filter,
} from 'lucide-react';

export const MyAppointments: React.FC = () => {
  const [appointments, setAppointments] = useState<Appointment[]>([]);
  const [loading, setLoading] = useState(true);
  const [filterStatus, setFilterStatus] = useState<string>('all');
  const [actionMsg, setActionMsg] = useState<{ text: string; type: 'success' | 'error' } | null>(null);

  useEffect(() => {
    fetchAppointments();
    const timer = setInterval(() => {
      fetchAppointmentsSilently();
    }, 7000);
    return () => clearInterval(timer);
  }, []);

  const fetchAppointmentsSilently = async () => {
    try {
      const data = await apiFetch<Appointment[]>('/api/appointments');
      setAppointments(data);
    } catch {}
  };

  const fetchAppointments = async () => {
    setLoading(true);
    try {
      const data = await apiFetch<Appointment[]>('/api/appointments');
      setAppointments(data);
    } catch (err) {
      console.error('Failed to load appointments:', err);
    } finally {
      setLoading(false);
    }
  };

  const handleStatusChange = async (id: string, newStatus: string) => {
    setActionMsg(null);
    try {
      await apiFetch(`/api/appointments/${id}/status`, {
        method: 'PATCH',
        body: JSON.stringify({ status: newStatus }),
      });
      setActionMsg({ text: `Appointment status updated to ${newStatus}.`, type: 'success' });
      await fetchAppointments();
    } catch (err: any) {
      setActionMsg({ text: err.message || 'Action failed', type: 'error' });
    }
  };

  const filtered = appointments.filter(a => {
    if (filterStatus === 'all') return true;
    return a.status === filterStatus;
  });

  return (
    <div className="space-y-6">
      
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl font-bold text-[#0f2942]">My Medical Appointments</h1>
          <p className="text-xs text-slate-500 mt-0.5">
            Review past consultations, upcoming bookings, queue tokens, and digital records.
          </p>
        </div>

        <Link
          to="/student/book"
          className="inline-flex items-center gap-2 px-3.5 py-2 bg-[#0f2942] hover:bg-[#163654] text-white text-xs font-medium rounded-lg transition shadow-xs self-start sm:self-auto"
        >
          <CalendarCheck className="w-4 h-4 text-teal-300" />
          <span>Book New Appointment</span>
        </Link>
      </div>

      {actionMsg && (
        <div
          className={`p-3 rounded-lg text-xs flex items-center gap-2 ${
            actionMsg.type === 'success'
              ? 'bg-emerald-50 text-emerald-800 border border-emerald-200'
              : 'bg-rose-50 text-rose-800 border border-rose-200'
          }`}
        >
          {actionMsg.type === 'success' ? (
            <CheckCircle className="w-4 h-4 text-emerald-600 shrink-0" />
          ) : (
            <AlertCircle className="w-4 h-4 text-rose-600 shrink-0" />
          )}
          <span>{actionMsg.text}</span>
        </div>
      )}

      {/* Filter Tabs */}
      <div className="flex items-center gap-1.5 overflow-x-auto pb-1 border-b border-slate-200">
        {[
          { key: 'all', label: 'All Appointments' },
          { key: 'booked', label: 'Booked' },
          { key: 'checked_in', label: 'Checked In' },
          { key: 'in_consultation', label: 'In Consultation' },
          { key: 'completed', label: 'Completed' },
          { key: 'cancelled', label: 'Cancelled' },
        ].map((tab) => (
          <button
            key={tab.key}
            onClick={() => setFilterStatus(tab.key)}
            className={`px-3 py-1.5 text-xs font-medium rounded-lg transition whitespace-nowrap ${
              filterStatus === tab.key
                ? 'bg-[#0f2942] text-white'
                : 'text-slate-600 hover:bg-slate-100 hover:text-slate-900'
            }`}
          >
            {tab.label}
          </button>
        ))}
      </div>

      {/* Appointments List */}
      {loading ? (
        <div className="p-8 text-center text-xs text-slate-400">Loading appointments...</div>
      ) : filtered.length === 0 ? (
        <div className="bg-white rounded-xl border border-slate-200 p-8 text-center">
          <CalendarCheck className="w-8 h-8 text-slate-300 mx-auto mb-2" />
          <p className="text-xs font-medium text-slate-700">No appointments found</p>
          <p className="text-[11px] text-slate-500 mt-0.5">You have no records matching the selected status filter.</p>
        </div>
      ) : (
        <div className="space-y-3">
          {filtered.map((appt) => (
            <div
              key={appt.id}
              className="bg-white rounded-xl border border-slate-200 p-5 shadow-2xs hover:border-slate-300 transition"
            >
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-100 pb-3">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-lg bg-teal-50 border border-teal-200 text-teal-800 flex flex-col items-center justify-center shrink-0">
                    <span className="text-[9px] uppercase font-bold text-teal-600">Token</span>
                    <span className="text-sm font-extrabold text-[#0f2942]">#{appt.token_number}</span>
                  </div>
                  <div>
                    <span className="font-mono text-xs text-slate-500">{appt.appointment_number}</span>
                    <h3 className="text-sm font-bold text-slate-900">{appt.doctor_name}</h3>
                    <div className="text-xs text-teal-800">{appt.doctor_specialization}</div>
                  </div>
                </div>

                <div className="flex items-center gap-3">
                  <StatusBadge status={appt.status} />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs py-3">
                <div>
                  <span className="text-slate-400 block text-[11px]">Appointment Slot</span>
                  <div className="font-medium text-slate-800 flex items-center gap-1.5 mt-0.5">
                    <Clock className="w-3.5 h-3.5 text-slate-500" />
                    <span>{appt.appointment_date} • {appt.time_slot}</span>
                  </div>
                </div>

                <div>
                  <span className="text-slate-400 block text-[11px]">Consultation Mode</span>
                  <div className="font-medium text-slate-800 flex items-center gap-1.5 mt-0.5">
                    <MapPin className="w-3.5 h-3.5 text-[#008780]" />
                    <span>In-Person OPD ({appt.doctor_room || 'Room 101, Ground Floor'})</span>
                  </div>
                </div>

                <div className="sm:col-span-1">
                  <span className="text-slate-400 block text-[11px]">Primary Reason for Visit</span>
                  <div className="font-semibold text-[#142F49] mt-0.5">
                    "{appt.reason_for_visit}"
                  </div>
                  {appt.symptoms_description && (
                    <div className="text-[11px] text-slate-500 mt-1 italic">
                      Details: {appt.symptoms_description}
                    </div>
                  )}
                </div>
              </div>

              {/* Action Buttons */}
              <div className="flex flex-wrap items-center justify-between gap-2 pt-3 border-t border-slate-100 text-xs">
                <div className="text-[11px] text-slate-500">
                  Booked on {new Date(appt.created_at).toLocaleDateString('en-IN')}
                </div>

                <div className="flex items-center gap-2">
                  {/* Check In Action */}
                  {appt.status === 'booked' && (
                    <button
                      onClick={() => handleStatusChange(appt.id, 'checked_in')}
                      className="inline-flex items-center gap-1 px-3 py-1.5 bg-[#EAF3FA] text-[#008780] hover:bg-teal-100 border border-[#DCE5EE] rounded-lg font-medium transition cursor-pointer"
                    >
                      <Radio className="w-3.5 h-3.5" />
                      <span>Check In at Health Center</span>
                    </button>
                  )}

                  {/* Cancel Appointment Action */}
                  {['booked', 'checked_in'].includes(appt.status) && (
                    <button
                      onClick={() => {
                        if (window.confirm('Are you sure you want to cancel this appointment?')) {
                          handleStatusChange(appt.id, 'cancelled');
                        }
                      }}
                      className="inline-flex items-center gap-1 px-2.5 py-1.5 text-rose-600 hover:bg-rose-50 border border-rose-200 rounded-lg font-medium transition cursor-pointer"
                    >
                      <XCircle className="w-3.5 h-3.5" />
                      <span>Cancel</span>
                    </button>
                  )}

                  {appt.status === 'completed' && (
                    <Link
                      to="/student/records"
                      className="inline-flex items-center gap-1 px-3 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg font-medium transition"
                    >
                      View Medical Summary
                    </Link>
                  )}
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

    </div>
  );
};
